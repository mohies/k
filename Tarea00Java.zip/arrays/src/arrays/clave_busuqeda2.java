package arrays;
import java.util.Arrays;
/**
 * Definir una función que tome como valor dos tablas: la primera con 
 * los 6 números de una apuesta primitiva y otra tabla ordenada de los 6 
 * números de la combinación ganadora. Devolver cuántos aciertos hay.
 * 
 * @author alu_tarde
 */
public class clave_busuqeda2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        int lote1[] = {3, 4, 5, 6, 32, 2};
        int lote2[] = {1, 3, 4, 7, 8, 9};

        int resultado = Acertado(lote1, lote2);
        System.out.println("Se ha acertado tantos números: " + resultado);
        int resultado2=primitiva(lote1,lote2);
        System.out.println("Otra opcion "+resultado2);
    }

    static int Acertado(int lote1[], int lote2[]) {
        int si = 0;

        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 6; j++) {
                if (lote1[i] == lote2[j]) {
                    si++; // Incrementar el contador solo cuando hay una coincidencia
                }
            }
        }
        return si;
    }
    
    static int primitiva(int lote1[],int lote2[]){
        int aciertos=0;
        for (int a:lote1){
            if(Arrays.binarySearch(lote2,a)>=0){ //la es la clave que quieres buscar
                aciertos++;
            }
        }
        return (aciertos);
    }
}
