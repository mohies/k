/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */
package arrays;
import java.util.Arrays;
/**
 *
 * @author alu_tarde
 */
public class tabla_ordenada {

    /**
     * @param args the command line arguments
     * crear una tabla original y con arraycopy que devuelva otra tabla igual que la original
     * y que apunte a esta tabla nueva con un elemento mas
     */
    public static void main(String args[]) {
        // TODO code application logic here
        int t[]={3,13,26,6,12};
         int[] tablaNueva = new int[t.length];  
         
          System.arraycopy(t, 0, tablaNueva, 0, t.length);

        // Añadir un elemento adicional a la nueva tabla
        int elementoAdicional = 6;
        tablaNueva = Arrays.copyOf(tablaNueva, tablaNueva.length + 1);
        tablaNueva[tablaNueva.length - 1] = elementoAdicional;

        // Mostrar las tablas
        System.out.println("Tabla Original: " + Arrays.toString(t));
        System.out.println("Nueva Tabla: " + Arrays.toString(tablaNueva));
        
    }
}
