/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */
package arrays;
import java.util.Arrays;
/**
 *
 * @author alu_tarde
 */
public class ejemploclasearrays {

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        // TODO code application logic here
        
        int t1[] = new int[5];
        Arrays.fill(t1, 2);
        Arrays.fill(t1, 1,4,3);
        
        //los metodos mas usados
        System.out.println(t1.length);

        
        for(int i=0;i<t1.length;i++){
            System.out.println(t1[i]);
        }
    }
    //los metodos mas usados
    
    /*esto hace que si valor es 2 rellena t con todos los valores 2
    static void fill(tipo t,tipo valor){
    arrays.fill(t1,2)
   } */
    
    /*static void fill(tipo t[],int desde,int hasta,tipo valor){}
    desde la posicion que queremos hasta donde que valor se tiene que rellenar
    y el hasta(se pone uno mas si queremos rellenar hasta 3 se pone 4)
    */
    /*for(declaracion variable:tabla)} ejemplo:
    
    double sueldos[]=new double[20];
    double sumatorio=0;
    for(double sueldoActual:sueldos)
    sumatorio=sumatorio+sueltoActual;
    
    */
    
    /* static void sort(tipo t[]) ordenar de manera decreciente/
    */
    
    /*static int binarySearch(Tipo t[],tipo clave)
    int pos=Arrays.binarySearch(t,3);->-2
    int indiceTuseccion=-pos-1=1 -pos<--2
    
    esto es si no encuentra el 3 en la tabla por ejemplo de un array
    si te devuelve un valor negativo es porque no lo ha encontrado
    
    static int binarysearch(tipo t[],int desde,int hasta,tipo clave)
    otra opcion
    */
    
    /*static tipo[] copyOf(tipo origen[],int longitud) esto para la tabla entera
    static tipo[] copyofRAnge[tipo origen[],int desde, int hasta)para rangos
    
    */
    
/* static void arrayCopy(Object tabla Origen,int posOrigen,Object tablaDestino,int posDestino,int longitud)
    Esto es para copiar de una tabla origen a una tabla destino no hay que importar se hace system.arraycopy*/
    
/* para insertar valores en la tabla y si esta ordenada la tabla hay que respetarla
    y insertar las tablas donde corresponde
    */
    
/*insercion no ordenada
    1. BUscamos donde insertar el valor(IndiceInsercion)
    2. Creamos nueva tabla(copia) con un elemento extra.
    3.Copiamos los elementos anteriores a indiceInsercion
    4.COpiamos los elementos posteriores.
    desplazamos una posicion
    5.INsertamos el nuevo valor
    */
