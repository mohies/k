/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */
package arrays;
import java.util.Scanner;
import java.util.Arrays;
/**
 *User
LEer y almacenar numeros enteros en una tabla apartir de las que se 
* construiran otras dos tablas con los elementos de valor pares y impares 
* de la primera ordenadas
 * @author alu_tarde
 */
public class ej10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        // TODO code application logic here
        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese la cantidad de números: ");
        int cantidadNumeros = scanner.nextInt();

        int[] numeros = new int[cantidadNumeros];


        for (int i = 0; i < cantidadNumeros; i++) {
            System.out.print("Ingrese el número " + (i+1) + ": ");
            numeros[i] = scanner.nextInt();
        }
 // Separar los números en pares e impares
        int[] pares = obtenerPares(numeros);
      

        // Mostrar los resultados
        Arrays.sort(pares);
        System.out.println("Números Pares: " + Arrays.toString(pares));
                }
    
        //hay que hacerlo con arraycopyof
         static int[] obtenerPares(int[] numeros) {
        int countPares = contarPares(numeros);
        int[] pares = new int[countPares];
        int indexPares = 0;

        for (int num : numeros) {
            if (num % 2 == 0) {
                pares[indexPares++] = num;
            }
        }

        return pares;
    }
         
         static int contarPares(int[] numeros) {
        int count = 0;
        for (int num : numeros) {
            if (num % 2 == 0) {
                count++;
            }
        }
        return count;
    }
}
        


