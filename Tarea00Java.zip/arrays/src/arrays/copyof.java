/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */
package arrays;
import java.util.Arrays;
/**
 *array con origen el 2 {2,4,6,8,10,12,14} hazme copyof para 6 ,
 * tabla completa y el 10 y luego copy range de [0,5] y [4,6]
 * @author alu_tarde
 */
public class copyof {

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        // TODO code application logic here
        int[] Array = {2, 4, 6, 8, 10, 12, 14};

        // 1. Copiar los  6 elementos
        int[] copyOfde6 = Arrays.copyOf(Array, 6);
        System.out.println("Copia de los primeros 6 elementos: " + Arrays.toString(copyOfde6));

        // 2. Copiar la tabla completa
        int[] copyOfCompleta = Arrays.copyOf(Array, Array.length);
        System.out.println("Copia de la tabla completa: " + Arrays.toString(copyOfCompleta));

        // 3. Copiar los elementos desde el 0 al 5
        int[] copyRange1 = Arrays.copyOfRange(Array, 0, 5);
        System.out.println("Copia de los elementos en el rango [0,5]: " + Arrays.toString(copyRange1));

        // 4. Copiar los elementos desde el indice 4 hasta el final
        int[] copyRange2 = Arrays.copyOfRange(Array, 4, 7);
        System.out.println("Copia de los elementos en el rango [4,6]: " + Arrays.toString(copyRange2));
        
        int destino[]={1,2,3,4,5};
        
        System.arraycopy(Array,2,destino,4,1);
        System.out.println(Arrays.toString(destino));

    }
}
