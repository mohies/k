/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */
package arrays;
import java.util.Scanner;
/**
 *introducir por telcado un numero y a continuacion solicitar al usuario que 
 * teclee n numeros enteros con esos numeros realizar media positivos media negativos 
 * y toal de 0 introducidos en java
 * @author alu_tarde
 */
public class ejcasa {

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
  Scanner scanner = new Scanner(System.in);

        System.out.print("Introduce la cantidad de números: ");
        int cantidadNumeros = scanner.nextInt();

        int sumaPositivos = 0;
        int sumaNegativos = 0;
        int contadorPositivos = 0;
        int contadorNegativos = 0;
        int contadorCeros = 0;

        for (int i = 0; i < cantidadNumeros; i++) {
            System.out.print("Introduce un número entero: ");
            int numero = scanner.nextInt();

            if (numero > 0) {
                sumaPositivos += numero;
                contadorPositivos++;
            } else if (numero < 0) {
                sumaNegativos += numero;
                contadorNegativos++;
            } else {
                contadorCeros++;
            }
        }

        double mediaPositivos = (contadorPositivos > 0) ? (double) sumaPositivos / contadorPositivos : 0;
        double mediaNegativos = (contadorNegativos > 0) ? (double) sumaNegativos / contadorNegativos : 0;

        System.out.println("Media de positivos: " + mediaPositivos);
        System.out.println("Media de negativos: " + mediaNegativos);
        System.out.println("Total de ceros: " + contadorCeros);
        
    }
}
