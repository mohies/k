/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */
package arrays;
import java.util.Scanner;
import java.util.Arrays;
/**
 *Crea una funcion(rellenaPares(int longitud, infin) que crea y devuelve una tabla ordenada que se rellena con numeros
 * pares aleatorios entre 2 y Fin
 * @author alu_tarde
 */
public class ej7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        int lon,fin;
        Scanner sc= new Scanner(System.in);
        
        System.out.println("Introducir valores de la tabla");
        lon=sc.nextInt(); 
        System.out.println("introduce el final tabla");
        fin=sc.nextInt();
        
        System.out.println(Arrays.toString(rellenaPares(lon,fin)));
        
         
    }
    
    static int[] rellenaPares(int lon,int fin){
        int tabla[]= new int[lon];
        for(int i=0;i<tabla.length;i++){
             do {
                tabla[i] = (int) (Math.random() * (fin -2+1) + 2);
            } while (tabla[i] % 2 != 0);
        }
        Arrays.sort(tabla);
        return tabla;
    }
    
    
}
