/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */
package arrays;

/**
 *Crea 3 tablas de 5 elementos cada una una int la segunda double y la tercera de booleanos,
 * muestra la referencia en la que se encuentra cada una de las tablas anteriores.
 * @author alu_tarde
 */
public class ejarray1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        // TODO code application logic here
        
        int edad[]=new int[5];
        edad[0]=2;
        edad[1]=3;
        edad[2]=4;
        edad[3]=5;
        edad[4]=6;
        System.out.println(edad[3]);
        System.out.println(edad);
        double altura[]=new double[5];
        altura[0]=2.3;
        altura[1]=4.5;
        altura[2]=1.5;
        altura[3]=0.99;
        altura[4]=1.1;
        System.out.println(altura[4]);
        System.out.println(altura);
        
        boolean vf[]=new boolean[5];
        vf[0]=true;
        vf[1]=true;
        vf[2]=false;
        vf[3]=true;
        vf[4]=false;
        System.out.println(vf[2]);
        System.out.println(vf);

    }
}
