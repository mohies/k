/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */
package arrays;
import java.util.Scanner;
/**
 *DAda la siguietne funcion int maximo(int t[]) y devolver el valor maximo de esa tabla
 * 
 * @author alu_tarde
 */
public class ej6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
       Scanner sc = new Scanner(System.in);
        
        System.out.print("introduce la longitud del array: ");
        int longitud = sc.nextInt();
        
        int[] miArray = new int[longitud];

        // Rellenamos el array
        for (int i = 0; i < miArray.length; i++) {
            System.out.print("introduce el valor para la posi " + i + ": ");
            miArray[i] = sc.nextInt();
        }

      
        int max = maximo(miArray);

        System.out.println("El valor max en el array es: " + max);

    }

    // Función pa encontrá el máh grandecito en el array
    static int maximo(int[] a) {
        if (a == null || a.length == 0) {
            System.out.println("El array no puede ser nulo o vacío");
        }

        int max = a[0]; 

        for (int i = 1; i < a.length; i++) {
            if (a[i] > max) {
                max = a[i]; 
            }
        }

        return max;
    }
    
}
