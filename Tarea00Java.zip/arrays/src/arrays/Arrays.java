/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package arrays;
import java.util.Scanner;
/**
 *
 * @author alu_tarde
 */
public class Arrays {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc=new Scanner(System.in);
        int edad[]=new int[5]; //es importante saber que el valor que toma es  la direccion de memoria
        
        System.out.println(edad);
    
        for(int i=0;4>=i;i++){
            edad[i]=sc.nextInt();
           
        }
        
          for(int i=0;4>=i;i++){
         System.out.println(edad[i]);
         }

        
        
        
        
    }
    
}
