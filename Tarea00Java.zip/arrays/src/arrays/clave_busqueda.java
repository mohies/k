/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */
package arrays;
import java.util.Scanner;

/**
 *crear una tabla y buscar un elemnto en la tabla con el int buscar(int t[],int clave
 * @author alu_tarde
 */
public class clave_busqueda {

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        // TODO code application logic here
         Scanner sc = new Scanner(System.in);
        
        int t[] ={1,2,3,4,5,6};
        
     // Solicitar el número a buscar
        System.out.print("Introduce el número a buscar: ");
        int numero = sc.nextInt();

        // Llamar a la función buscar e imprimir el resultado
        boolean encontrado = buscar(t, numero);
        if (encontrado) {
            System.out.println("El número " + numero + " está presente en el array.");
        } else {
            System.out.println("El número " + numero + " no está presente en el array.");
        }
    }

    // Función para buscar si un número está presente en el array
    static boolean buscar(int t[], int numero) {
        for (int i = 0; i < t.length; i++) {
            if (t[i] == numero) {
                return true; // Devolver true si el número está presente en el array
            }
        }
        return false; // Devolver false si el número no está presente en el array
    }
}
    

