/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */
package arrays;
import java.util.Arrays;
/**
 *HAcer esa funcion int[] sinRepetidos(int t[]) devuelve una tabla de la longitud apropiada con los elementos t,
 * donde se han eleminado los datos repetidos
 * @author alu_tarde
 */
public class ej8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        // TODO code application logic here
        int t[]={3,13,26,6,12,26,3,13,12};
        int[] resultado=sinRepetidos(t);
        
        System.out.println("EL resultado seria "+Arrays.toString(resultado));
        
    }
    
   static int[] sinRepetidos(int t[]){
       int n = t.length; // Longitud de la tabla original
        int count = 0; //pa contar elementos unicos
        for (int i = 0; i < n; i++) {
            boolean unico = true;
            for (int j = i + 1; j < n; j++) {
                if (t[i] == t[j]) {
                    unico = false;
                    break;
                }
            }
            if (unico) {
                count++;
            }
        }
        

        int[] resultado = new int[count];
        int indice = 0;

 
        for (int i = 0; i < n; i++) {
            boolean unico = true;
            for (int j = i + 1; j < n; j++) {
                if (t[i] == t[j]) {
                    unico = false;
                    break;
                }
            }
            if (unico) {
                resultado[indice++] = t[i];
            }
        }

        return Arrays.copyOf(resultado, resultado.length);
    }
}
