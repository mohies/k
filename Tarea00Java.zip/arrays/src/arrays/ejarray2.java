/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */
package arrays;
import java.util.Arrays;
/**
 *Craer una tabla de longitud 10 que se inicializara con numeros aleatorios 
 * comprendidos entre 1 y 100 y mostrar la suma de todos los numeros aleatorios.
 * @author alu_tarde
 */
public class ejarray2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        // TODO code application logic here
        
        int numeros[]=new int[10];
        System.out.println(numeros.length);
     
        for(int i=0;i<10;i++){
            numeros[i]=(int)(Math.random()*101);
            System.out.println(numeros[i]);
        }
        int suma=0;
        for(int total:numeros){
            suma=suma+total;
        }
        System.out.println(suma);
    }
}
