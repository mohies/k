/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */
package arrays;
import java.util.Arrays;
/**Introducir por teclado un n
 *
 * @author alu_tarde
 */
public class ejarray3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        // TODO code application logic here
        int edad[]={8,3,5,2};
        
        
        Arrays.sort(edad);
        
        System.out.println(Arrays.toString(edad));//para convertir array en string
        
    }
}
