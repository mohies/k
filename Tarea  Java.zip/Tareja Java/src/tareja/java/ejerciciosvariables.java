/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tareja.java;
            
/**
 *
 * @author alu_tarde
 */
public class ejerciciosvariables {
    
    public enum Tamaño{P,G}

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
         // Declaración  de variables
        int diaAño = 827;
        double numero = 6770005741.12364;
        boolean jefe = true;
        final int PI = 314;
        String diaSemana = "Miercoles";
        long miliseg = 1277332800000L;
        double totalPVP = 10111.678;
        Tamaño valores = Tamaño.P;
        
         // Mostrar resultados usando println
        System.out.println("----- EJERCICIO DE VARIABLES Y TIPOS DE DATOS  -----");
        System.out.println("\t"+"El valor de la variable diaAnio es " + diaAño + ".");
        System.out.println("\t"+"El valor de la variable número es " + numero + ".");
        System.out.println("\t"+"El valor de la variable jefe es " + jefe + ".");
        System.out.println("\t"+"El valor de la variable PI es " + PI + ".");
        System.out.println("\t"+"El valor de la variable diaSemana es " + diaSemana + ".");
        System.out.println("\t"+"El valor de la variable miliseg es " + miliseg + ".");
        System.out.println("\t"+"El valor de la variable totalPVP es " + totalPVP + ".");
        System.out.println("\t"+"El valor de la variable valores es " + valores + ".");
        
        
             // Mostrar resultados usando print
        System.out.print("----- EJERCICIO DE VARIABLES Y TIPOS DE DATOS  -----");
        System.out.print("\n\t"+"El valor de la variable diaAnio es " + diaAño + ".");
        System.out.print("\n\t"+"El valor de la variable número es " + numero + ".");
        System.out.print("\n\t"+"El valor de la variable jefe es " + jefe + ".");
        System.out.print("\n\t"+"El valor de la variable PI es " + PI + ".");
        System.out.print("\n\t"+"El valor de la variable diaSemana es " + diaSemana + ".");
        System.out.print("\n\t"+"El valor de la variable miliseg es " + miliseg + ".");
        System.out.print("\n\t"+"El valor de la variable totalPVP es " + totalPVP + ".");
        System.out.print("\n\t"+"El valor de la variable valores es " + valores + "."+"\n");
        
        
             // Mostrar resultados usando printf
        System.out.printf("----- EJERCICIO DE VARIABLES Y TIPOS DE DATOS -----\n");
        System.out.printf("\t"+"El valor de la variable diaAño es %d.\n", diaAño);
        System.out.printf("\t"+"El valor de la variable jefe es %b.\n", jefe);
        System.out.printf("\t"+"El valor de la variable PI es %d.\n", PI);
        System.out.printf("\t"+"El valor de la variable diaSemana es %s.\n", diaSemana);
        System.out.printf("\t"+"El valor de la variable miliseg es %d.\n", miliseg);
        System.out.printf("\t"+"El valor de la variable totalPVP es %f.\n", totalPVP);
        System.out.printf("\t"+"El valor de la variable totalPVP en notación científica es %1.6E.\n", totalPVP);
        System.out.printf("\t"+"El valor de la variable número es %f.\n", numero);
        System.out.printf("\t"+"El valor de la variable valores es %s.\n", valores);
        
        /*s->cadenas
                d->Enteros
                        c->caracteres
                                b->booleanos
                                        f->real*/
    }
    
}
