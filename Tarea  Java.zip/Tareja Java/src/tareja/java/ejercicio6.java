/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */
package tareja.java;
/*6.- Diseña un programa Java que cree un tipo enumerado para los siguientes productos:
tornillo, martillo, tuerca, chincheta. El programa debe realizar las siguientes
operaciones:
 Crear una variable m del tipo enumerado y asignarle como valor martillo.
Mostrar por pantalla su valor.
 Asignar a la variable m, la cadena de texto "tuerca". Mostrar por pantalla el valor
de la variable de tipo enumerado tras realizar la asignación.*/
/**
 *
 * @author alu_tarde
 */
public class ejercicio6 {
    
    public enum Productos{tornillo, martillo, tuerca, chincheta}

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        // TODO code application logic here
        
        Productos m = Productos.martillo;
        System.out.println("El valor del productos es "+m);
        m = Productos.tuerca;
        System.out.println("EL valor de productos ahora es " + m);
        
    }
}
