/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */
package tareja.java;

import java.util.Scanner;

/*5.- Diseña un programa Java que pida dos números por teclado, escriba en pantalla si  
son iguales o distintos y además muestre el resultado de multiplicarlos. */


/**
 *
 * @author alu_tarde
 */
public class ejercicio5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        // TODO code application logic here
        int num1,num2;
        String cadena;
        Scanner sc=new Scanner(System.in);
        
        System.out.println("Escriba el primer número");
         num1 = sc.nextInt();
        System.out.println("Escriba el segundo número");
         num2 = sc.nextInt();
            
         cadena=(num1==num2)?"iguales":"distintos";
           System.out.printf("Los numeros %d y %d son %s\n",num1,num2,cadena);
         
            System.out.println("El resultado de la multiplicacion es " + (num1*num2));
             
    }
}
