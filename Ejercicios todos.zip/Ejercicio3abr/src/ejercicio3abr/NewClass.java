/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio3abr;

import java.util.Comparator;

/**
 *
 * @author alu_tarde
 */
public class NewClass implements Comparator {
    
    @Override
    public int compare (Object o1, Object o2){
        String s1=(String)o1;
        String s2=(String)o2;
        
        return s1.compareTo(s2);
          
    }
    
}
