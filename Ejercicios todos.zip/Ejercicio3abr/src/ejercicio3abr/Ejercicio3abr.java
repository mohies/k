/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio3abr;
import java.util.Arrays;
import java.util.Scanner;
/**Una lista  string con cadena de caracteres que hasta que el usuario inserte la cadena fin ya no se introduce y ordenarla
 * por orden alfabetico.HAy que mostrarla antes y despues.
 * @author alu_tarde
 */
public class Ejercicio3abr {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
Scanner sc =new Scanner(System.in);
   
// TODO code application logic here
                Lista l1=new Lista();
   
        System.out.println("Introducir un valor");
        String valor = sc.nextLine();
        
        while (!valor.equals("fin")) { 
     
            l1.insertarPrincipio(valor);
            
            System.out.println("Introducir un valor");
            valor = sc.nextLine();
        }
        
        l1.ordenar();
        System.out.println(l1.toString());  
        
       
        
       
    }
   
    
}
