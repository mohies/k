/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package ejercicio18mar;

/**
 * //APARTIR DE ESTE PROYECTO VAMOS A CREAR LA COLA DOBLE
 * @author alu_tarde
 */
public interface Cola {
    
    void encolar(int valor);
    int desencolar();
    
}
