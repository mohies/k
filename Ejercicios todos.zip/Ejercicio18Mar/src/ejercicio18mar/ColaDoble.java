/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package ejercicio18mar;

/**
 *APARTIR DE ESTE PROYECTO VAMOS A CREAR LA COLA DOBLE va a encolar al principio y desencolar al final
 * hacemos que cola doble herede de cola
 * @author alu_tarde
 */
public interface ColaDoble extends Cola {
    void encolarF(int valor);
    int desencolarF();
    
    
}
