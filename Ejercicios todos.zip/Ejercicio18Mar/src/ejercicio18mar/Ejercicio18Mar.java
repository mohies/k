/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio18mar;
import java.util.Scanner;
/**
 * cREAMOS UNA INTERFAZ COLA PARA NUMEROS ENTEROS Y POSITIVOS Y QUE VA A TENER ESTOS DOS METODOS.
 * 2.SOLICITAR AL USUARIO VALORES MAYORES O MENOS QUE 0 Y LOS VAMOS ENCOLADO HASTA QUE INTRODUZCA UN VALOR NEGATIVO Y DESENCOLAROS POR PANTALLA
 * @author alu_tarde
 */
public class Ejercicio18Mar {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
//        Scanner sc=new Scanner(System.in);
//        System.out.println("Introduce un valor");
//        int valor=sc.nextInt();
        Lista lista=new Lista();
//        
//        while (valor>=0) {  
//          
//     
//           if (valor>=0) {
//         lista.encolar(valor); 
//            }
//               System.out.println("Introduce un valor");
//         valor=sc.nextInt();
//        }
//        System.out.println("Asi quedaria la tabla "+lista.toString());  
//        for (int i = 0; i < lista.tabla.length; i++) {
//             System.out.println("Se elimina el objeto "+i+" posicion"+lista.toString()); 
//        lista.desencolar();
//        
//        }
        
        
    
        Lista lista2=new Lista();//si ponemos ColaDoble coge los de cola tambien si ponemos solo COla los de cola solo
       
        lista2.encolarF(5);
        lista2.encolarF(3);
        lista2.encolarF(2);
       
        System.out.println(lista2.toString());
        
        
        lista2.desencolarF();
        
        System.out.println(lista2.toString());
        
        lista2.desencolarF();
        
        System.out.println(lista2.toString());
        
        Scanner sc=new Scanner(System.in);
        System.out.println("Introduce un valor");
        int valor=sc.nextInt();
        
//       IMPLEMENTA UN PROGRAMA EN EL QUE USANDO UNA COLA ANONIMA SE ENCOLA NUMEROS 
//       ENTEROS HASTA QUE SE INTRODUCE UN VALOR NEGATIVO Y LUEGO SE DESENCOLA TODOS LOS 
//       VALORES MOSTRANDOLOS POR PANTALLA 

    Cola c1=new Cola(){
        Lista l=new Lista(); //crear un objeto nuevo dentro eso es local aqui dentro, tambien quitamos el implements de Lista ya que lo que queremos que sea local dentro aqui y quen o va afectar al resto
        @Override
         public void encolar(int valor){
             
         while (valor>=0) {  
           if (valor>=0) {
             l.encolar(valor);
            }
               System.out.println("Introduce un valor");
         valor=sc.nextInt();
        }
             
            System.out.println(lista);  
        }

            @Override
            public int desencolar() {
                for (int i = 0; i <l.tabla.length ; i++) {
              
            lista.desencolar();
            System.out.println("Se elimina el objeto "+i+" posicion"+lista.toString());
              
            }
        return lista.desencolar();
         
    }

    

    };
    
    c1.encolar(valor);
    c1.desencolar();
    
}
}