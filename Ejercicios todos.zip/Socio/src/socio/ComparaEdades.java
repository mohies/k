/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package socio;

import java.util.Comparator;

/**
 *
 * @author alu_tarde
 */
public class ComparaEdades implements Comparator {
    
    //he hecho otra clase porque quiero para comparar otro atributo
    @Override
    public int compare (Object o1, Object o2){
        Socio s1=(Socio)o1;
        Socio s2=(Socio)o2;
        
        return s1.calcularEdad()-s2.calcularEdad();
    }
}
