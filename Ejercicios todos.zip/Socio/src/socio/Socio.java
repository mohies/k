/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package socio;
//tiene un constructor que es publico y creamos un metodo que se llame edad que no tiene parametro entrada y devuevle la edad
import java.time.LocalDate;
import java.time.Month;
import java.time.temporal.ChronoUnit;

/**
 * 
 * @author alu_tarde
 */
public class Socio implements Comparable {
    int id;
    String nombre;
    LocalDate fechaNacimiento;

    public Socio(int id, String nombre, String fechaNacimiento) {
        this.id = id;
        this.nombre = nombre;
        this.fechaNacimiento = LocalDate.parse(fechaNacimiento);
    }
    
    
    int calcularEdad(){
        return (int)fechaNacimiento.until(LocalDate.now(),ChronoUnit.YEARS);
    }

    @Override
    public String toString() {
        return "Socio{" + "id=" + this.id + ", nombre=" + this.nombre + ", fechaNacimiento=" + this.calcularEdad() + '}';
    }
    //ordenar por edades ascendentes y si tienen las misma edad que vaya antes el que tenga un numero socio menor
//    @Override
//    public int compareTo(Object o){
//        Socio s2 = (Socio)o;
//        
//        
//        
//        return id-s2.id; //se muestra por orden alfabetico
//    }
    
//    @Override
//    public int compareTo(Object o){
//        Socio s2 = (Socio)o;
//        int resultado=this.calcularEdad()-s2.calcularEdad();
//        int ids = this.id-s2.id;
//        if(this.calcularEdad()==s2.calcularEdad()){
//            return ids; //se muestra por orden alfabetico
//        }else{
//            
//           return resultado;
//            
//        }
//        
//        
//    } 


    
      @Override
    public int compareTo(Object o){
        Socio s2 = (Socio)o;
        int resultado=this.calcularEdad()-s2.calcularEdad();
        int ids = this.id-s2.id;
        if(this.calcularEdad()==s2.calcularEdad()){
            return ids; //se muestra por orden alfabetico
        }else{
            
           return resultado;
            
        }
        
        
    }      
    
    
}
