/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package socio;

import java.util.Comparator;

/**
 *
 * @author alu_tarde
 */
public class ComparadorId implements Comparator {
    @Override
    public int compare (Object o1, Object o2){
        Socio s1 = (Socio)o1;
        Socio s2 = (Socio)o2;
        
        return s1.id-s2.id;
        
    }
}
