/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */
package socio;

import java.util.Arrays;

/**
 *
 * @author alu_tarde
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        // TODO code application logic here
        
        Socio s=new Socio(1,"Mohcen","2001-01-30");
         Socio s2=new Socio(2,"Alvaro","1999-01-30");
         Socio s3=new Socio(3,"FErnando","1998-01-30");
         Socio s4=new Socio(4,"FErnando","1998-01-30");
        System.out.println(s.calcularEdad());
        
        System.out.println(s.toString());
        
        System.out.println(s2.compareTo(s));
        
        Socio[] tabla=new Socio[4];
        tabla[0]=s3;
        tabla[1]=s;
        tabla[2]=s4;
        tabla[3]=s2;
        
        System.out.println(Arrays.deepToString(tabla));
        Arrays.sort(tabla);
        System.out.println(Arrays.deepToString(tabla));
        
        ComparaEdades comparador1= new ComparaEdades();
        
        System.out.println(comparador1.compare(s3, s2));
      
        Arrays.sort(tabla,comparador1); //esto para ordenar en funcion del comparador que hemos hecho en una clase extra
        
        System.out.println(Arrays.deepToString(tabla));
        
        ComparaNombres comparador2 = new ComparaNombres();
        
        Arrays.sort(tabla,comparador2.reversed()); //para hacerlo en orden inverso
        System.out.println("Por nombre"+Arrays.deepToString(tabla));
        
        Arrays.sort(tabla);
        
        System.out.println("Por edad si no por id "+Arrays.deepToString(tabla));
        
        
        /*Ejercicio Interfaces de comparación (3/04)

    Usar la clase Lista (tipo Object) para insertar 4 elementos de tipo Socio (a elección del programador). 
        El orden natural de dichos elementos será la edad en modo creciente. Ordenar la tabla y mostrarla 
        antes y después de ordenarla. Además, manteniendo el mismo orden natural, ordenar la lista de
        socios por orden creciente de id, y mostrarla de nuevo.
*/
        Lista l1=new Lista();
        
        l1.insertarPrincipio(s);
        l1.insertarPrincipio(s2);
        l1.insertarFinal(s3);
        l1.insertarFinal(s4);
        
        System.out.println(l1.toString());
        l1.ordenar(comparador1); //puedo quitar el comparador 1 y dejarlo vacio ya que me lo ordenara por defecto por el compareto que esta dentro de la clase socio al tener objetos socio dentro de la lista
        System.out.println(l1.toString());
        ComparadorId comparador3 = new ComparadorId();
        l1.ordenar(comparador3);
        System.out.println(l1.toString());
        
    }
    
    
}
