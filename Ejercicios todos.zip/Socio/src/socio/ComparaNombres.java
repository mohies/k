/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package socio;

import java.util.Comparator;

/**
 *
 * @author alu_tarde
 */

public class ComparaNombres implements Comparator {
  //ordenar la tabla alfabetica de nombres invertidos  
     @Override
    public int compare (Object o1, Object o2){
        Socio s1 = (Socio)o1;
        Socio s2 = (Socio)o2;
        
        return s1.nombre.compareTo(s2.nombre);
        
    }
}
