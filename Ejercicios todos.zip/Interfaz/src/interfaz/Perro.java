/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package interfaz;

/**
 *
 * @author alu_tarde
 */
public class Perro implements Sonido {
    
    int edad;
    
    @Override
    public void voz(){ //tiene que ser publica siemrpe
        System.out.println("guau");
    }
    
    @Override
    public void vozDurmiendo(){
        System.out.println("BRRR");
    }
    
    void saludar(){
        System.out.println("Hola");
    }
    
    public int compareTo(Object o){
        Perro perro2=(Perro)o;
        int resultado;
       
        if (edad==perro2.edad) {
            resultado=0;
        }else if(edad>perro2.edad){
            resultado=1;
            
        }else{
            resultado=0;
        }
        return resultado;
        
        //otra forma resultado=this.edad - otroPErro.edad si ahcemos las cuentas sale negativo 0 o un numero positivo
    }
}
