/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package interfaz;

/**
 *
 * @author alu_tarde
 */
public class Interfaz {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Gato g = new Gato();
        Perro p= new Perro();
        Perro p2= new Perro();
        p.edad=3;
        p.edad=2;
        g.llorar();
        g.voz();
        p.voz();
        g.vozDurmiendo();
        p.vozDurmiendo();
        
        Sonido son=new Perro(); //esto es poliformismo 
        son.voz();/**dssdasdsda*/
       //no puedo invocar los de son.saludar porque es de sonido
        son.vozDurmiendo();
        son=new Gato();
//        son=son.llorar(); no se puede acceder porque son es de la interfaz en cambio el objeto arriba propio si puede
        son.voz();
        son.vozDurmiendo();
        
        Sonido.bostezo();// el metodo estático
        
        Sonido sonAnimalNuevo= new Sonido(){ // no se esta creando un objeto se esta creando como una clase
            @Override
            public void voz(){
                System.out.println("asdsdaasdasd"); //esto es la clase anonimo para hacerlo hay que implementar los metodos abstractos y podemos reimplementar los no abstractos.
            } //basicamente es un objeto que no pertenece a ninguna clase
        };
        
        sonAnimalNuevo.voz();
        
       
        
        
    }
    
}
