/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package interfaz;

/**
 *
 * @author alu_tarde
 */
public interface Sonido {
    int version=1; //lo van a ver todos las clases que se implemente y todos son estaticos y constantes dichos atributos
                    //Perro.verison SOnido.version asi se indiciaria
    void voz(); //en las interfaces se da por supuesto que son aabstracto
    
    default void vozDurmiendo(){
        System.out.println("Zzz");//Es publico y no estatico necesito un  objeto para acceder a el
        voz();
    }
    
    static void bostezo(){ //este no se le puede hacer override
        System.out.println("¡Aaaaaauu!");
    }
}
