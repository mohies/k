/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package interfaz;

/**
 *
 * @author alu_tarde
 */
public class Gato implements Sonido {
      @Override
    public void voz(){ //tiene que ser publica siemrpe
        System.out.println("miau");
    }
    
    @Override
    public void vozDurmiendo(){
        System.out.println("rrr");
    }
    
   public void llorar(){
        System.out.println("muaaaaaaaaaaaaaaaa");
    }
}
