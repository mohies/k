/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicioscalendarioclase;

/**
 *
 * @author marta
 */
public class Calendario {

     int a, m, d;

    public Calendario(int d, int m, int a) {
        this.a = a;
        this.m = m;
        this.d = d;
        compruebaFecha();
    }

    private void compruebaFecha() {

        int diasMes[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
        if (a <= 0) {
            a = 1;
        }
        if (m < 1 || m > 12) {
            m = 1;
        }
        if (d < 1 || d > diasMes[m - 1]) {
            //if (d<1 || !compruebaMes(d,m)) {
            d = 1;
        }
    }

    /*private boolean compruebaMes(int dia, int mes){
       boolean res = false;
       switch(mes){
           case 1:
               if(dia>0 && dia<=31){
                   res = true;
               }
               break;
               case 2:
               if(dia>0 && dia<=28){
                   res = true;
               }
               break;
               case 3:
               if(dia>0 && dia<=31){
                   res = true;
               }
               break;
               case 4:
               if(dia>0 && dia<=30){
                   res = true;
               }
               break;
               case 5:
               if(dia>0 && dia<=31){
                   res = true;
               }
               break;
               case 6:
               if(dia>0 && dia<=30){
                   res = true;
               }
               break;
               case 7:
               if(dia>0 && dia<=31){
                   res = true;
               }
               break;
               case 8:
               if(dia>0 && dia<=31){
                   res = true;
               }
               break;
               case 9:
               if(dia>0 && dia<=30){
                   res = true;
               }
               break;
               case 10:
               if(dia>0 && dia<=31){
                   res = true;
               }
               break;
               case 11:
               if(dia>0 && dia<=30){
                   res = true;
               }
               break;
               case 12:
               if(dia>0 && dia<=31){
                   res = true;
               }
               break;
       }
       return res;
   }*/
    void incrementarDia() {
        int diasMes[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
        d++;
        if (d > diasMes[m - 1]) {
            d = 1;
            incrementaMes();
        }
    }

    void incrementaMes() {
        m++;
        if (m > 12) {
            m = 1;
            incrementaAño();
        }
        /*
        // Esta parte es por si, al incrementar el valor del mes, se queda un valor incorrecto en el d�a para el mes resultante.
        // No era necesario hacer esta comprobaci�n, pero lo pongo comentado por si alguno lo ha hecho, que est� bien :)
        int diasMes[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
        if (d > diasMes[m - 1]) {
            d = 1;
        }*/
    }

    void incrementaAño() {
        a++;
    }
    
    

    void mostrar() {
        /*String ceroDia = d < 10 ? "0" : "";
        String ceroMes = m < 10 ? "0" : "";

        System.out.println(ceroDia + d + "/" + ceroMes + m + "/" + a);*/
        
        System.out.println(d + "/" + m + "/" + a);
    }

    boolean iguales(Calendario otro) {
        return (this.d == otro.d
                && this.m == otro.m
                && this.a == otro.a);
    }

    
    
}
