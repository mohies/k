/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicioscalendarioclase;

/**
 *
 * @author alu_tarde
 */
public class CalendarioExacto extends Calendario {

    private int hora, min;

    public CalendarioExacto(int hora, int min, int d, int m, int a) {
        super(d, m, a);
        if (hora >= 0 && hora <= 23) {
            this.hora = hora;

        } else {
            this.hora = 0;
        }
        if (min >= 0 && min <= 59) {
            this.min = min;
        } else {
            this.min = 1;
        }

    }

    void incMin(int valor) {
        this.min++;
        if (this.min > 59) {
            this.hora++;
        }

    }

    @Override
 public String toString() {
    if ((this.min >= 0 && this.min <= 9) || (this.hora >= 0 && this.hora <= 9)) {
        // Si min está entre 0 y 9, o si hora está entre 0 y 9
        if (this.min >= 0 && this.min <= 9) {
            return d + "/" + m + "/" + a + " tal dia son las " + hora + ":0" + min;
        } else {
            return d + "/" + m + "/" + a + " tal dia son las " + "0" + hora + ":" + min;
        }
    } else {
        // Si tanto min como hora no están entre 0 y 9
        return d + "/" + m + "/" + a + " tal dia son las " + hora + ":" + min;
    }
 }

}
