/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tarea3tri;

/**
 *
 * @author alu_tarde
 */
public class Conjuntos extends Lista {
   
    public Conjuntos(){
        tabla=new int[0];
    
    }
    
    @Override
    void insertarPrincipio(int nuevo){
        boolean repetido=false;
        for (int i = 0; i < tabla.length; i++) {
            if (tabla[i]==nuevo) {
                repetido=true;
            }
            
        }
        
        if (repetido==false) {
            super.insertarPrincipio(nuevo);
            
        }else{
            System.out.println("Esta repetido");
        }
        
    }
    @Override
    void insertarFinal(int nuevo){
        boolean repetido=false;
         for (int i = 0; i < tabla.length; i++) {
            if (tabla[i]==nuevo) {
                repetido=true;
            }
            
        }
        
        if (repetido==false) {
            super.insertarFinal(nuevo);
            
        }else{
            System.out.println("Esta repetido");
        }
        
        
    }
    
    @Override
    public boolean equals(Object otro){
        Conjuntos otroConj=(Conjuntos)otro;
        boolean iguales =false;
        int contador=0;
         if (tabla.length!=otroConj.tabla.length) {
            iguales=false;
         }else{
             
         
        for (int i = 0; i < tabla.length; i++) {
            for (int j = 0; j < otroConj.tabla.length; j++) {
                if (tabla[i]==otroConj.tabla[j]) {
                    contador++;
                
                }
                
            }
            
            
        }
        }
         if(contador==tabla.length && contador==otroConj.tabla.length){
             return iguales=false;
         }else{
             return iguales=false;
         }
    }

   
    
    
    
    
    @Override
    public void mostrarTipoLista(){
        System.out.println("Mostrando eso es un Conjunto");
     
        
    }
    
}
