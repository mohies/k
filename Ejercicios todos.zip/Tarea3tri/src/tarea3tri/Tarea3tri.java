/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tarea3tri;

/**
 *
 * @author alu_tarde
 */
public class Tarea3tri {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Conjuntos c1=new Conjuntos();
        Conjuntos c2=new Conjuntos();
        c1.insertarPrincipio(3);
        c1.insertarFinal(4);
        c2.insertarPrincipio(3);
    
        System.out.println(c1.toString());
        System.out.println(c2.equals(c2));
    }
    
}
