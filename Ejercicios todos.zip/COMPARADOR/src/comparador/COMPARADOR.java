/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package comparador;

import java.util.Arrays;

/**IMPLEMENTA UNA CLASE COMPARADORA QUE TE PERMITA COMPARAR NUMEROS ENTEROS EN NUMEROS DECRECIENTE 
CREAR UNA TABLA DE 20 ELEMENTOS ALEATORIOS QEU COMPRENDA ENTRE 1 Y 100 Y ORDENARLO EN DECRECIENTE
 *
 * @author alu_tarde
 */
public class COMPARADOR {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Integer tabla[]=new Integer[20]; //esta es la clase de los int por eso se usa
        
        
        for (int i = 0; i < tabla.length; i++) {
            tabla[i]=(int)(Math.random()*101);
           
        }
        
        System.out.println(Arrays.toString(tabla));
        
        NewClass comparador=new NewClass();
        
        Arrays.sort(tabla,comparador /*puedo crearme el objeto aqui new NewClass()*/);
        
        System.out.println("ordenandolo en modo decreciente"+Arrays.deepToString(tabla));
    }
    
}
