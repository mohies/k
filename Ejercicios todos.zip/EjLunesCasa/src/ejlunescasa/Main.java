/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */
package ejlunescasa;

/**
 *
 * @author alu_tarde
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        // TODO code application logic here
        
    
        System.out.println("Es numero 2.4 "+esNumero(2));
     
        
    }
    
    static boolean esNumero(Object a){
        boolean numero=false;
        Class cl=a.getClass();
        
        Class sc=cl.getSuperclass();
        String nombreSuperClase=sc.getSimpleName();
        if(nombreSuperClase.equals("Number")){
            numero=true;
        }
        return numero;
    }
    

        
    }

