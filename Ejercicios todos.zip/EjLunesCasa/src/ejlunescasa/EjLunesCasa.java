/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejlunescasa;

/** *Diseña la funcion estatica esUnNUmero(object objeto) que devuelva true si es un numero
 * @author alu_tarde
 */
public class EjLunesCasa {

    /**
     * @param args the command line arguments
     * 
     * 
     */
    
    public static boolean esUnNumero(Object obj){
    String Number = obj.getClass().getSuperclass().getSimpleName();
    return Number != null && Number.equals("Number");
    }
   
    
}
