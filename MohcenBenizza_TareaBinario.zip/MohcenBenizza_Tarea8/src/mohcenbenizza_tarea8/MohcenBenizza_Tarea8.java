/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package mohcenbenizza_tarea8;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author alu_tarde
 */
public class MohcenBenizza_Tarea8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        ObjectInputStream inputStream = null;
        ObjectOutputStream outputStream = null;
        
        //1.leer fichero
        
        
        try {
            inputStream = new ObjectInputStream(new FileInputStream("lista.dat"));   
            while (true) {
                String[] nombres=(String[]) inputStream.readObject();
                Arrays.sort(nombres);
                System.out.println(Arrays.toString(nombres));
                            System.out.println("Lista vacia");

            }
            
            
       } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error al leer los números del archivo binario: " + e.getMessage());
        }
        
            Scanner sc = new Scanner(System.in);
           String nombre=sc.nextLine();
          while (!nombre.equals("fin")) {            
                  nombre=sc.nextLine();
        }
  
     
        System.out.println("Ingrese longitud de tabala");
         int n = sc.nextInt();
            String[] nombres = new String[n];
        
            
            for (int i = 0; i < nombres.length; i++) {
                if (!nombre.equals("fin")) {
           
            nombres[i] =nombre;  
                }
            
        }
    
        
            
        
        try {
           outputStream=new ObjectOutputStream(new FileOutputStream("lista.dat")); 
           outputStream.writeObject(nombres);
           System.out.println("Los nombres se han guardado correctamente");
           
        } catch (IOException e) {
            System.err.println("Error al guardar los números en el archivo binario: " + e.getMessage());
        }
        
    }
    
}
