#!/bin/bash

for i in $(seq 1 5)
do
	read -p "Introduce 5 nombres " nombre
	echo  $nombre >> nombres-ordenado.txt

done
echo " ordenado"
sort nombres-ordenado.txt
echo "sin ordenar"
cat nombres-ordenado.txt
