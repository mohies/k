#!/bin/bash

for i in $(seq 1 5)
do
	read -p "Introduce nombre apellidos y dni" nombre

	echo $nombre >> datos.txt
done

