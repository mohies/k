#!/bin/bash

read -p "Introduce el numero del que quieras multiplicar" num

while [ $num != "q" ]
do
	echo "Tabla de $num: " >> compratem.txt

	for i in $(seq 1 10)
	do
		res=`expr $num \* $i`
		echo "$num*$i=$res" >> compratem.txt
	done

	read -p "Introduce otro numero para la tabla" num
done
