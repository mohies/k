#!/bin/bash

function suma(){
	suma=`expr $num1 + $num2`
	echo "Esta es la suma $suma"
}

function mul(){
        mul=`expr $num1 \* $num2`
        echo "Esta es la suma $mul"
}

function tabl(){
        for i in $(seq 1 10)
	do
		tabl=`expr $num1 \* $i`
		echo "La tabla de multiplicar del $tabl "
	done
}

function tabl2(){
        for i in $(seq 1 10)
        do
                tabl=`expr $num2 \* $i`
                echo "La tabla de multiplicar del $tabl "
        done
}

function tabl2(){
        for i in $(seq 1 10)
        do
                tabl=`expr $num2 \* $i`
                echo "La tabla de multiplicar del $tabl "
        done
}

function may(){
        if [ $num1 -gt $num2 ]
	then
		echo "el numero mayor es $num1"
	else
		echo "el numero mayor es $num2"
	fi
}

function resmay(){
        if [ $num1 -gt $num2 ]
        then
                echo "el numero mayor es $num1"
		resta=`expr $num1 - $num2`
		echo "La resta es $resta"
        else
                echo "el numero mayor es $num2"
		resta2=`expr $num2 - $num1`
		echo "La resta es $resta2"
        fi
}

function divmay(){
        if [ $num1 -gt $num2 ]
        then
                echo "el numero mayor es $num1"
                div=`expr $num1 / $num2`
                echo "La division es $div"
        else
                echo "el numero mayor es $num2"
                div2=`expr $num2 - $num1`
                echo "La division es $div2"
        fi
}





read -p "escribe una opcion " opcion
while [ $opcion -ne 9 ]
do
	case $opcion in
		1) read -p "Introduce num1" num1
	  	   read -p "Introduce num2" num2;;
		2) suma;;
		3)mul;;
		4)tabl;;
		5)tabl2;;
		6)may;;
		7)resmay;;
		8)divmay;;
                9)echo "Saliste";;
		*)echo "Opcion no valida";;
		esac
  read -p "escribe otra opcion" opcion
done
