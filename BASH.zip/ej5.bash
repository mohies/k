va=1
va2=2
va3=3

resul=`expr $va + $va2 + $va3`
echo "La suma es : $resul "
resul2=`expr $va - $va2 - $va3`

echo " la resta es: $resul2 " 
