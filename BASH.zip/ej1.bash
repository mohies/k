va="Mohcen"
va2="tt@gmail.com"
va3="23"

re="el $va tiene $va3 años  y el correo es $va2"
echo $re
