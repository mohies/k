#!/bin/bash

for i in $(seq 1 5)
do	
	read -p "Introduce 5 nombres " nombres
	echo $nombres >> mi-agenda1.txt
done

cat mi-agenda1.txt
