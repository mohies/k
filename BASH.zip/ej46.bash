#!/bin/bash

for i in $(seq 1 3)
do
	read -p "Introduce nombre " nombre
	echo $nombre >> mifichero.txt
done


sort mifichero.txt >> mificheroordenado.txt
echo "fichero sin ordenar"
cat mifichero.txt
echo "fichero ordenado"
cat mificheroordenado.txt

echo "fichero borrado"
rm mifichero.txt
