echo hola papa $1


echo que tal sta mama $2

echo "Número de valores pasados por parámetros: $#"

