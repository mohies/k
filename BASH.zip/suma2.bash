#!/bin/bash

echo "Suma de los numeros naturales for"
echo "ponme los numeros que quieras"
read a
read b
suma=0
contador=1
echo "1.Opcion quieres desde $a a $b"
echo "2.Opcion si quieres desde $b a $a"
echo "3.Salir"
read opcion


case $opcion in 

		1)for i in $(seq $a $b )
			do

				suma=`expr $suma + $i`
			done

			echo "La suma  de $a a $b $suma "
			;;
		2)for i in $(seq $b -1  $a )
                	do

                        	suma=`expr $suma + $i`
                	done

                	echo "La suma de $b a $a $suma "
                	;;
        	3)echo "salir";;
		*)echo "Opcion no valida"	
esac
echo "Has salido hermano"
