read -p "Introduce el primer amigo1" a1
read -p "Introduce el primer amigo2" a2
read -p "Introduce el primer amigo3" a3

read -p "Introduce el numero1  amigo1" n1
read -p "Introduce el numero2  amigo2" n2
read -p "Introduce el numero3  amigo3" n3

read -p "Introduce provincia  amigo1" p1
read -p "Introduce provincia  amigo2" p2
read -p "Introduce provincia  amigo3" p3

re= "El email de mi amigo Lalo es :$a1"
"EL telefono lalo es:$n1"
"Lalo nacio:$p1"
"El email de mi amigo Lolo es :$a1"
"EL telefono lolo es:$n1"
"Lolo nacio:$p1"
"El email de mi amigo Lelo es :$a1"
"EL telefono Lelo es:$n1"
"Lelo nacio:$p1"

