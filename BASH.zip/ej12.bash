echo "Introduce un número:"
read numero

if [ $numero -gt 200 ]; then
    echo "El número es mayor que 200"
fi


