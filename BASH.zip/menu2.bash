#!/bin/bash
function carp()
{
	read -p "Nombre de la carpeta " carpeta
	dir $carpeta
	
}

function articu()
{
	for i in $(seq 1 5)
	do
		read -p "Introduce articulos y su precio" articulos
		echo $articulos >> ADIOS/micompra.txt
	done
}



read -p "Escoge una opcion " opcion

while [ $opcion -ne 10 ] 
do
	case $opcion in
		1)carp;;
		2)articu;;
		3);;
		4) grep 
		10);;
		*) echo "Opcion no valida";;
	esac
	read -p "Escoge una opcion" opcion
done
