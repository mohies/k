echo "Introduce equipo 1"
read e1
echo "Introduce el equipo 2"
read e2
echo "Goles 1"
read g1
echo "Goles 2"
read g2

re="Partido: $e1 - $e2 Resultado: $g1-$g2"

echo $re
