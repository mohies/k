#!/bin/bash

read -p "Introduce nmobre amigo y corre " n

while [ $n != "salir" ]
do
	echo $n >> amigos-email.txt
	read -p "Introduce nombre y correo " n
done

echo "mostar contenido archivo"

cat amigos-email.txt|grep *@gmail* 
