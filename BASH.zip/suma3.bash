#!/bin/bash

echo "Introduce un numero para realizar su factorial"
read num

f=1
for i in $(seq 1 $num )
do
	f=`expr $f \* $i` 
done

echo "El factoria de $num es $f"

