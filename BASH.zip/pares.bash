#!/bin/bash

read -p "Introduce num1 " num1

read -p "Introduce nm2 " num2

while [ $num2 -lt $num1 ] 
do
                read -p "Introduce num2 mayor" num2
done


suma=0

for i in $(seq $num1   $num2)
do
	if [ `expr $i % 2` == 0 ]
	then
		suma=`expr $suma + $i`
	
	fi	

done

echo "la suma de los pares " $suma
