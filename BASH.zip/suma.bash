#!/bin/bash

echo "Suma de los 100 primeros numeros naturales"

suma=0
contador=1

until [ $contador -gt 100 ]  
do
	suma=`expr  $suma + $contador`
	contador=`expr $contador + 1`
done

echo "La suma de los 100 primeros $suma "
