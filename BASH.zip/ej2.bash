va="REX"
read -p "INtroduce las patas" va2

re="El $va tiene $va2 patas"
echo $re
