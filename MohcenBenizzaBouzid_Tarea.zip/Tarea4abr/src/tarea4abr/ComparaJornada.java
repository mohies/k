/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tarea4abr;


import java.util.Comparator;

/**
 *
 * @author alu_tarde
 */
public class ComparaJornada implements Comparator{
    
    //En esta clase lo que hacemos es comparar dos objetos de jornada para coger el personal que menos ha trabajado
    @Override
     public int compare (Object o1, Object o2){
        Jornada j1= (Jornada)o1;
        Jornada j2 = (Jornada)o2;
        
        return j1.minTrabajados()-j2.minTrabajados();
     
     }
    
}
