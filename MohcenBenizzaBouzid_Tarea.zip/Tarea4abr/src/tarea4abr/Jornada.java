/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tarea4abr;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;

/**
 *
 * @author alu_tarde
 */
public class Jornada implements Comparable  {
     final String DNI;
     final LocalDate fecha;
     final LocalTime horaEntrada;
     final LocalTime horaSalida;
     
     public Jornada(String DNI,LocalDate fecha,LocalTime horaEntrada,LocalTime horaSalida){
         this.DNI=DNI;
         this.fecha=fecha;
         this.horaEntrada=horaEntrada;
         this.horaSalida=horaSalida;
     }
     
     //Hemos creado la funcion minutosTrabajados con las horas de entrada y salida para que nos calcule 
     //desde la hora de entrada hasta la hora de salida a base de minutos.
     
     public int minTrabajados(){
         return (int)horaEntrada.until(horaSalida,ChronoUnit.MINUTES);
     }
     
     //COmparamos los valores para que nos lo ordene por el numero de Dni mas grande si no pues por la fecha mas grande de los dos
     @Override
     public int compareTo(Object o){
         Jornada j2 = (Jornada)o;
         int resultado;
         resultado= this.DNI.compareTo(j2.DNI);
         
         if(resultado==0){
             return resultado= this.fecha.compareTo(j2.fecha);
         }else{
             return resultado;
         }
         
         
     }
 

    //El metodo toString de tipo String.
     @Override
    public String toString() {
        return "DNI= " + DNI + ", fecha= " + fecha + " minutos trabajados= "+ this.minTrabajados();
    }
     
     
     
     
     
     
    
}
