/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tarea4abr;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.Month;

/**
 *
 * @author alu_tarde
 */
public class Tarea4abr {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
      //Creamos el objeto de las 3 jornadas y una lista
        
        Jornada j1=new Jornada("32",LocalDate.of(2021, Month.JUNE, 13),LocalTime.of(8, 0),LocalTime.of(15, 30));
        Jornada j2=new Jornada("21",LocalDate.of(2021, Month.JULY, 18),LocalTime.of(8, 0),LocalTime.of(15, 25));
        Jornada j3=new Jornada("32",LocalDate.of(2021, Month.APRIL, 9),LocalTime.of(8, 0),LocalTime.of(15, 00));
        
        
        Lista l1 = new Lista();
        //Insertamos los valores en la lista con las funciones de lista
        l1.insertarFinal(j1);
        l1.insertarFinal(j2);
        l1.insertarFinal(j3);
        
        //mostrar lista sin ningun orden
        System.out.println("Lista normal sin realizar ninguna modificacion"+l1.toString());
        
        //Ordenamos los valores en la lista con las funciones de lista
        l1.ordenar();
        
        System.out.println("Mostrando lista ordenada por Dni y si no por fecha "+l1.toString());
        
        //Hemos creado un objeto comparador de la clase Compara jornada para luego ordenarla con dicho comparador
        ComparaJornada compara = new ComparaJornada();
        
        l1.ordenar(compara);
        
        System.out.println("Mostrando lista ordenada por jornada con menos minutos "+l1.toString());
        
        
        
    }
    
}
