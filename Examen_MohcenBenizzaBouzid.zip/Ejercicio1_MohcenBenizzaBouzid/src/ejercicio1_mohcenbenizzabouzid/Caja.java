/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio1_mohcenbenizzabouzid;

/**
 *
 * @author alumnado
 */
public class Caja   {
    //los ponemos final los atributos ya que son inmutables
    final double Ancho;
    final double Alto;
    final double Fondo;
     String etiqueta;
     
    //Constructor excepto el atributo etiqueta 
    public Caja(double Ancho, double Alto, double Fondo) {
        this.Ancho = Ancho;
        this.Alto = Alto;
        this.Fondo = Fondo;
    }
    
    //metodo calculavolumen
    double calculaVolumen(){
    return Ancho*Alto*Fondo;
}
    //metodo setEtiqueta

    public void setEtiqueta(String Etiqueta) {
        this.etiqueta = etiqueta;
    }

    
    //metodo ToString de tipo String para mostrar los 4 atributos.
    @Override
    public String toString() {
        return  " ancho: " + Ancho + " alto: " + Alto + " fondo :" + Fondo + " etiqueta: " + etiqueta;
    }
    
    
    
    
    
    
    
    
    

}