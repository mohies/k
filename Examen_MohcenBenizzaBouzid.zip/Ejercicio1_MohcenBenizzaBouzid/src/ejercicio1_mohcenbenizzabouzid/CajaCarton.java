/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio1_mohcenbenizzabouzid;

/**
 *
 * @author alumnado
 */
public class CajaCarton extends Caja {
    //los atributos 
    protected double SuperficieCaja; //ponemos el atributo asi ya que dice que  cuyo valor será visible desde todas las subclases de CajaCarton
    static double SuperficieCartonTotal; //lo ponemos estatico ya que sumará a la superficie total cada vez que se cree una nueva caja de cartón.

   
    public CajaCarton(double Ancho, double Alto, double Fondo) {
        super(Ancho, Alto, Fondo);
        SuperficieCaja=2 * (Ancho * Alto + Ancho * Fondo + Alto * Fondo);
        SuperficieCartonTotal+=calculaVolumen()+SuperficieCaja;
        
        
    }
    //metodo get Superficie caja que te devuelve la SUperficie
    public double getSuperficieCaja() {
        return SuperficieCaja; 
    }
    
    //calculamos el 80 porciento reimplementando el metodo y heredando
   @Override
   double calculaVolumen(){
    return  super.calculaVolumen()*0.8;
} 

   //metodo to string reimplementado y añadiendo la cadena toString
    @Override
    public String toString() {
        String cad=super.toString();
        return cad + " CajaCarton :" + " SuperficieCaja: " + SuperficieCaja + " SuperficieCartonTotal: " + SuperficieCartonTotal;
    }

   
    
   
    
    
    
    
}
