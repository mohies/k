/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio1_mohcenbenizzabouzid;

/**
 *
 * @author alumnado
 */
public class Ejercicio1_MohcenBenizzaBouzid {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        
        CajaCarton c1=new CajaCarton(1,1,2);
        c1.etiqueta="Direccion"; //le establecemos la etiqueta direccion
        //Imprimir el calculo del volumen
        System.out.println("Volumen "+c1.calculaVolumen());
        
        System.out.println("Caja 1 "+c1.toString());
                

         //Imprimir el calculo del volumen

        CajaCarton c2 = new CajaCarton(1,2,2);
        
        System.out.println("Volumen "+c2.calculaVolumen());
        
        c2.etiqueta ="Diraccion";//le establecemos la etiqueta direccion
        
        System.out.println("Caja 2 "+c2.toString());
    }
    
}
