/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio2_mohcenbenizzabouzid;

import java.util.Comparator; //importamos el comparator

/**
 *
 * @author alumnado
 */
public class ComparaEdad implements Comparator {
    //creamos esta clase para comparar y establecer un orden los dos objetos de la clase
    @Override
    public int compare(Object o1,Object o2){
    Futbolista f1=(Futbolista)o1;
    Futbolista f2=(Futbolista)o2;
   
    int resultado=-(f1.edad-f2.edad); //para que sea por edad decreciente
        if (resultado==0) {
            resultado=f1.n_goles-f2.n_goles; //condicion si son iguales que sea por el numero de goles
            
            
        }
          
        return resultado;
   
       
       
   }
    
}
