/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio2_mohcenbenizzabouzid;

import java.util.Arrays;

/**
 *
 * @author alumnado
 */
public class Ejercicio2_MohcenBenizzaBouzid {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //creamos 5 objetos futbolistas  y los insertamos
        Futbolista f1 = new Futbolista("1A", "Ramos", 30, 15);
        Futbolista f2 = new Futbolista("3B", "Hazar", 25 ,10);
        Futbolista f3 = new Futbolista("2C", "Fekir", 28, 12);
        Futbolista f4 = new Futbolista("5D", "Ronaldo", 34, 20);
        Futbolista f5 = new Futbolista("4E", "Messi", 34, 18);
        
        
        Futbolista[] tabla=new Futbolista[5];
        
        tabla[4]=f1;
        tabla[3]=f2;
        tabla[2]=f3;
        tabla[1]=f4;
        tabla[0]=f5;
        
        //Ordenamos la tabla por orden natural 
        Arrays.sort(tabla);
        
        System.out.println("Ordenados por Dni" + Arrays.deepToString(tabla));
        
        ComparaNombre c1= new ComparaNombre(); //creamos el objeto compara para ordenarlo
        
        //ordenamos comparando NOmbre
        Arrays.sort(tabla,c1);
        System.out.println("Ordenados por nombre"+Arrays.deepToString(tabla));
        
        ComparaEdad c2= new ComparaEdad(); //creamos el objeto comparaedad para ordenarlo
        
        Arrays.sort(tabla,c2);
        
        System.out.println("Ordenados por Edad y goles" + Arrays.deepToString(tabla) );
        
        Futbolista f6 = new Futbolista("4E", "Vinicius", 23, 18); //creamos un nuevo objeto para hacer la igualdad
        
        System.out.println("Comprobar si estos dos futbolistas son iguales en dni "+f5.equals(f6));
        
        //compropbar cual de destos dos futbolistas por el orden natural va antes y no sale negativo ya que va despues
        System.out.println("Ordenar por los dni estos dos futbolistas"+f1.compareTo(f2));
        
    }
    
}
