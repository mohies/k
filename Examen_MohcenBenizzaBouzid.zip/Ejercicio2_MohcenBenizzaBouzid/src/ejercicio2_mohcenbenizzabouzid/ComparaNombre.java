/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio2_mohcenbenizzabouzid;

import java.util.Comparator;

/**
 *
 * @author alumnado
 */
public class ComparaNombre  implements Comparator  {
        //creamos esta clase para comparar los dos objetos de la clase y ordenar por nombre alfabetico
    @Override
    public int compare(Object o1,Object o2){
    Futbolista f1=(Futbolista)o1;
    Futbolista f2=(Futbolista)o2;
    
    return f1.nombre.compareTo(f2.nombre);
       
       
   }
}
