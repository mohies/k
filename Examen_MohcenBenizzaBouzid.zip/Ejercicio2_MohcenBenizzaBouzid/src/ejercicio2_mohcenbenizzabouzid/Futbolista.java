/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio2_mohcenbenizzabouzid;

/**
 *
 * @author alumnado
 */
//ponemos implements comparable ya que estableceremos un criterio de orden natural en la propia clase
public class Futbolista implements Comparable { 
    //atributos
    String dni;
    String nombre;
    int edad;
    int n_goles;

    //Constructor
    public Futbolista(String dni, String nombre, int edad, int n_goles) {
        this.dni = dni;
        this.nombre = nombre;
        this.edad = edad;
        this.n_goles = n_goles;
    }

    //metodo ToString
    @Override
    public String toString() {
        return "Futbolista " + "dni:" + dni + ", nombre:" + nombre + ", edad:" + edad + ", n_goles:" + n_goles ;
    }

    //metodo equals para ver si dos objetos son iguales en dni.
    @Override
    public boolean equals(Object o) {
       Futbolista f2=(Futbolista)o;
       
       return this.dni.equals(f2.dni);
       
    }
    
    //Metodo comparteTo para establece el criterio de orden natural en la propia clase
   @Override
   public int compareTo(Object o){
    Futbolista f2=(Futbolista)o;
    
    return this.dni.compareTo(f2.dni);
       
       
   }
    
    
    
    
    
    
}
