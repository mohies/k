/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio2_mohcenbenizza;

/**
 *
 * @author alu_tarde
 */

//Objetos de cada clase
public class Calendario {
    private int dia;
    private int mes;
    private int ano;
    //Constructor
    public Calendario(int dia,int mes,int ano){
        if(ano>=1){
            this.ano=ano;
        } //hacemos las condiciones para saber que cada mes y el dia estan en el rango adecuado de las fechas
        if(mes==1||mes==3||mes==5||mes==7||mes==8||mes==10||mes==12||mes==8||mes==9||mes==10||mes==12){
            this.mes=mes;
            if (dia>0 && dia<=31) {
                this.dia=dia;
                this.mes=mes;
            }else{
                this.mes=1;
                this.dia=1;
            }
            }else if (mes==4 || mes==6 || mes==9 || mes==11) {
                this.mes=mes;
                if(dia>0 && dia<=30){
                    this.dia=dia;
                }else{
                    this.mes=1;
                    this.dia=1;
                }
                    
            }
            
            else if(mes==2){
                this.mes=mes;
                if (dia>0 && dia<=28)
                this.dia=dia;
   
        }else{
                this.mes=1;
                this.dia=1;
            }
        
    }
    //metodos
    void incrementarDia(){
        this.dia++;
         if (this.dia>30|| this.dia>31|| this.dia>29) {
                this.dia=1;
                this.mes++;
            }
         if(this.mes>=12){
                this.mes=1;
                ano++;
                
            }   
       //incrementamos los dias con una serie condiciones para que no se sobresalga
    }
    
    void incrementarMes(){
        this.mes+=1;
        
         if (this.mes>12) {
                this.dia=1;
                this.mes=1;
                ano++;
            } //incrementamos los Meses con una serie condiciones para que no se sobresalga
    }
    //incrementamos el año
    void incrementarAño(int cantidad){
        this.ano+=cantidad;
    }
    
    //mostrar los valores
    void mostrar(){
        System.out.println(dia+"/"+mes+"/"+ano);
        
    }
    
     boolean  iguales(Calendario otraFecha){
        boolean identicos=false;
        //la condicion si es distinto de la fecha mes año y dia se sobresale.
        if ((otraFecha.dia==this.dia) && (otraFecha.mes==this.mes) && (otraFecha.ano==this.ano)) {
            identicos=true;
        }else{
        
          identicos=false;
        }
        return identicos;
    }
    
}
