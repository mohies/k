/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */
package ejercicio2_mohcenbenizza;

/**
 *
 * @author alu_tarde
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        // TODO code application logic here
        
        //Probamos con fechas erroneas
        Calendario c3=new Calendario(700,16,2023);
        c3.mostrar();
        
        //Probamos con fechas correctas
        Calendario c1=new Calendario(31,12,2023);
        Calendario c2=new Calendario(31,12,2023);
        c1.mostrar();
        System.out.println(c1.iguales(c2));
        c1.incrementarDia();
        c1.mostrar();
        c1.incrementarMes();
        c1.mostrar();
        System.out.println(c3.iguales(c1));
        //hacemos un bucle para recorres los dias facilmente con la cantidad que queramos
        for (int i = 0; i < 10; i++) {
           c1.incrementarDia();
        }
    
         c1.incrementarAño(20);
 
        
        c1.mostrar();
        
        
        
    }
}
