/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */
package Pilas;

/**
 *
 * @author alu_tarde
 */
public class Pilas {

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        // TODO code application logic here
        Lista elemento= new Lista();
        Pila el2= new Pila(elemento);
        
        el2.apilar(-2);
        el2.mostrar(); //Dara un error al intentar apilar un valor negativo
        
        el2.apilar(2);
        el2.mostrar();
        el2.desapilar(2);
        
       
        for (int i = 0; i < 10; i++) { //aqui lo que hacemos es añadir o apilar los 10 elementos
            el2.apilar(i);
        }
      
         el2.mostrar();
        for (int i = 0; i < 10; i++) {
            el2.desapilar(i);  //aqui lo que haremos es eliminar los elementos los 10   
        }
        el2.desapilar(3);
        
        el2.mostrar();
        
    }
}
