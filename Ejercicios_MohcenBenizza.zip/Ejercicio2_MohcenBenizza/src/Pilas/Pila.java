/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pilas;
import java.util.Arrays;
/**
 *
 * @author alu_tarde
 */
public class Pila {
    Lista lista=new Lista();
    
        //Constructor
    public Pila(Lista lista){
        this.lista=lista;
    }
    //metodos
    void apilar(int valor){
        if (valor>=0) { //apilamos el valor o lo añadimos al final si es positivo en caso de no serlo nos da un error
            lista.insertarFinal(valor);
        }else{
            System.out.println("Da un error");
        }
    }
    
    void desapilar(int valor){ //en esta funcion nos fijaremos si esta vacia si no procederemos a eliminarlas
        if(lista.numeroElementos()==0){
            System.out.println("Esta vacia la pila");
        }else{
            lista.eliminar((lista.numeroElementos()-1));
            
            //lo mas complejo en esta parte eliminamos los indices de cada ejercicio poco a poco
            //si tiene longitud 5 pues 5-1=4 
        }
    }
    
  void mostrar(){ //funcion que muestra los valores de la pila compuesta por el metodo de Lista.
      System.out.println("Mostrando valores de la pila" );
      this.lista.mostrar();
  }
}
